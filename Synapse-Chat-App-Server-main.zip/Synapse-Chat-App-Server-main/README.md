# Synapse-Chat-App-Server

Hello wonderful people! I started working on this project, and I didn't have time to continue it.
If you would like to edit this is any type of way go right ahead.

Also the client code is in:
https://raw.githubusercontent.com/ou1z/Roblox-Scripts/master/Synapse-Chat-App.lua
